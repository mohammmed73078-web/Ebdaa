import { useEffect, useMemo, useState } from "react";
import { useRouter } from "expo-router";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { audiences, offerSlides, services } from "@/constants/services";
import { brand } from "@/constants/brand";
import { BrandHeader, FooterContact, IconTile, openWhatsApp, PageScreen, SectionHeading, WhatsAppButton } from "@/components/brand-ui";

export default function HomeScreen() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [slide, setSlide] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setSlide((current) => (current + 1) % offerSlides.length), 5200);
    return () => clearInterval(timer);
  }, []);
  const searchResults = useMemo(() => {
    const clean = query.trim().toLowerCase();
    if (!clean) return [];
    return services.filter((item) => `${item.name} ${item.detail} ${item.audience}`.toLowerCase().includes(clean)).slice(0, 4);
  }, [query]);
  const currentOffer = offerSlides[slide];

  return (
    <PageScreen>
      <BrandHeader />
      <View style={styles.hero}>
        <View style={styles.heroTopline}><View style={styles.heroDot} /><Text style={styles.heroEyebrow}>مكتبتك الأكاديمية والمهنية</Text></View>
        <Text style={styles.heroTitle}>من أول صفحة..{`\n`}لحدي التفوق!</Text>
        <Text style={styles.heroSub}>ملخصات، تنظيم، عروض ومساندة عملية — في مكان واحد وبخطوات بسيطة.</Text>
        <View style={styles.heroButtons}>
          <View style={{ flex: 1, minWidth: 205 }}><WhatsAppButton label="اطلب الآن عبر واتساب" onPress={() => openWhatsApp("sudan", "السلام عليكم، أود طلب خدمة من مكتبة الإبداع. أخبروني بالتفاصيل المناسبة لي.")} /></View>
          <Pressable onPress={() => router.push("/services")} style={({ pressed }) => [styles.heroOutline, pressed && { opacity: 0.8 }]}><Text style={styles.heroOutlineText}>استكشف الخدمات</Text></Pressable>
        </View>
        <View style={styles.heroNote}><MaterialCommunityIcons name="heart-outline" size={17} color={brand.colors.gold} /><Text style={styles.heroNoteText}>إنت ما براك.. نحن معاك!</Text></View>
      </View>

      <View style={styles.searchBlock}>
        <Text style={styles.searchTitle}>تدور على خدمة معينة؟</Text>
        <View style={styles.searchInputWrap}><MaterialCommunityIcons name="magnify" size={21} color={brand.colors.muted} /><TextInput value={query} onChangeText={setQuery} placeholder="ابحث عن ملخص، عرض، تنسيق..." placeholderTextColor="#8A91A0" style={styles.searchInput} textAlign="right" returnKeyType="search" onSubmitEditing={() => router.push("/services")} /></View>
        {query ? <View style={styles.searchResults}>{searchResults.length ? searchResults.map((item) => <Pressable key={item.id} onPress={() => router.push("/request")} style={styles.searchResult}><Text style={styles.searchResultName}>{item.name}</Text><MaterialCommunityIcons name="arrow-top-left" size={16} color={brand.colors.gold} /></Pressable>) : <Text style={styles.noResult}>ما لقينا نتيجة مطابقة. جرّب كلمة ثانية.</Text>}</View> : null}
      </View>

      <View style={styles.sectionGap}>
        <SectionHeading eyebrow="اختار اللي يناسبك" title="خدمات لكل مرحلة" subtitle="مهما كان دورك، نرتب لك طريق أوضح للإنجاز." />
        <View style={styles.audienceGrid}>{audiences.map((item) => <Pressable key={item.name} onPress={() => router.push("/services")} style={({ pressed }) => [styles.audienceCard, pressed && { transform: [{ translateY: 2 }] }]}><IconTile icon={item.icon} /><Text style={styles.audienceTitle}>{item.name}</Text><Text style={styles.audienceEyebrow}>{item.eyebrow}</Text><Text style={styles.audienceDesc}>{item.description}</Text><Text style={styles.cardLink}>شوف الخدمات <MaterialCommunityIcons name="arrow-left" size={14} color={brand.colors.gold} /></Text></Pressable>)}</View>
      </View>

      <View style={styles.offerCard}>
        <View style={styles.offerTextCol}>
          <View style={styles.offerPill}><MaterialCommunityIcons name="crown-outline" size={14} color={brand.colors.navy} /><Text style={styles.offerPillText}>العروض الذهبية</Text></View>
          <Text style={styles.offerEyebrow}>{currentOffer.eyebrow}</Text>
          <Text style={styles.offerTitle}>{currentOffer.title}</Text>
          <Text style={styles.offerDetail}>{currentOffer.detail}</Text>
          <Text style={styles.offerNote}>{currentOffer.note}</Text>
          <Pressable onPress={() => openWhatsApp("sudan", `السلام عليكم، أود الاستفسار عن العرض: ${currentOffer.title} — ${currentOffer.detail}.`)} style={styles.offerCta}><Text style={styles.offerCtaText}>اسأل عن العرض</Text><MaterialCommunityIcons name="arrow-left" size={16} color={brand.colors.navy} /></Pressable>
        </View>
        <View style={styles.offerMedallion}><MaterialCommunityIcons name={currentOffer.icon as never} size={36} color={brand.colors.gold} /><Text style={styles.offerBigMark}>✦</Text></View>
        <View style={styles.offerDots}>{offerSlides.map((_, index) => <View key={index} style={[styles.offerDot, slide === index && styles.offerDotActive]} />)}</View>
      </View>

      <View style={styles.sectionGap}>
        <SectionHeading eyebrow="ثلاث خطوات واضحة" title="كيف تطلب؟" />
        <View style={styles.stepsRow}>{[
          { n: "01", title: "اختر الخدمة", desc: "حدد احتياجك من قائمة الخدمات.", icon: "cursor-default-click-outline" },
          { n: "02", title: "راسلنا واتساب", desc: "أرسل التفاصيل والملف إن وجد.", icon: "whatsapp" },
          { n: "03", title: "استلم طلبك", desc: "نتابع معك ونوضح وقت التسليم.", icon: "package-variant-closed-check" },
        ].map((step) => <View key={step.n} style={styles.stepCard}><View style={styles.stepTop}><Text style={styles.stepNumber}>{step.n}</Text><MaterialCommunityIcons name={step.icon as never} size={21} color={brand.colors.gold} /></View><Text style={styles.stepTitle}>{step.title}</Text><Text style={styles.stepDesc}>{step.desc}</Text></View>)}</View>
      </View>

      <View style={styles.sectionGap}>
        <SectionHeading eyebrow="ثقة تُبنى بالتجربة" title="آراء العملاء" subtitle="نحرص على مشاركة آراء حقيقية وبموافقة أصحابها." />
        <View style={styles.reviewCard}><View style={styles.reviewStars}>{[0, 1, 2, 3, 4].map((n) => <MaterialCommunityIcons key={n} name="star-outline" size={17} color={brand.colors.gold} />)}</View><Text style={styles.reviewPlaceholder}>نجهّز هذه المساحة لآراء طلابنا وعملائنا الموثقة. شاركنا تجربتك بعد استلام خدمتك.</Text><Text style={styles.reviewFooter}>رأيك يساعدنا نتحسّن</Text></View>
      </View>
      <FooterContact />
      <Text style={styles.footerLine}>من أول صفحة.. لحدي التفوق!</Text>
    </PageScreen>
  );
}

const styles = StyleSheet.create({
  hero: { backgroundColor: brand.colors.navy, borderRadius: 27, padding: 24, paddingTop: 25, marginBottom: 19, position: "relative", overflow: "hidden" },
  heroTopline: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 15 },
  heroDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: brand.colors.gold },
  heroEyebrow: { fontSize: 12, fontWeight: "700", color: "#D8C79E" },
  heroTitle: { color: brand.colors.white, fontSize: 37, lineHeight: 48, fontWeight: "900", textAlign: "right", letterSpacing: -0.3, maxWidth: 340 },
  heroSub: { color: "#D5DFED", fontSize: 14, lineHeight: 23, textAlign: "right", marginTop: 12, maxWidth: 390 },
  heroButtons: { flexDirection: "row", alignItems: "center", gap: 9, marginTop: 20, flexWrap: "wrap" },
  heroOutline: { minHeight: 48, borderRadius: 14, paddingHorizontal: 14, borderWidth: 1, borderColor: "#647795", alignItems: "center", justifyContent: "center" },
  heroOutlineText: { color: "#F8F5EE", fontSize: 12, fontWeight: "700" },
  heroNote: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 19 },
  heroNoteText: { fontSize: 12, color: "#E7D7B1", fontWeight: "700" },
  searchBlock: { backgroundColor: brand.colors.paper, padding: 17, borderRadius: 20, borderWidth: 1, borderColor: brand.colors.line, marginBottom: 32 },
  searchTitle: { fontSize: 14, color: brand.colors.navy, fontWeight: "800", textAlign: "right", marginBottom: 11 },
  searchInputWrap: { minHeight: 48, borderRadius: 13, backgroundColor: "#F5F3EF", flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 12, borderWidth: 1, borderColor: "#ECE7DE" },
  searchInput: { flex: 1, color: brand.colors.ink, fontSize: 13, minHeight: 46 },
  searchResults: { marginTop: 8 },
  searchResult: { paddingVertical: 10, paddingHorizontal: 4, borderBottomWidth: 1, borderColor: brand.colors.line, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  searchResultName: { fontSize: 13, color: brand.colors.ink, fontWeight: "700" },
  noResult: { color: brand.colors.muted, fontSize: 12, textAlign: "right", padding: 9 },
  sectionGap: { marginBottom: 34 },
  audienceGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  audienceCard: { flexGrow: 1, flexBasis: 145, minHeight: 170, padding: 15, borderRadius: 18, backgroundColor: brand.colors.paper, borderWidth: 1, borderColor: brand.colors.line },
  audienceTitle: { marginTop: 12, fontSize: 17, fontWeight: "800", color: brand.colors.navy, textAlign: "right" },
  audienceEyebrow: { fontSize: 10, color: brand.colors.gold, fontWeight: "800", marginTop: 3, textAlign: "right" },
  audienceDesc: { color: brand.colors.muted, fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 7, flex: 1 },
  cardLink: { color: brand.colors.navy, fontSize: 11, fontWeight: "800", marginTop: 10, textAlign: "right" },
  offerCard: { backgroundColor: "#F0E5CD", borderRadius: 24, padding: 20, flexDirection: "row", alignItems: "center", marginBottom: 35, borderWidth: 1, borderColor: "#E2D2AF", minHeight: 228, overflow: "hidden" },
  offerTextCol: { flex: 1, alignItems: "flex-start", paddingRight: 105 },
  offerPill: { backgroundColor: "#E2CF9F", flexDirection: "row", gap: 5, alignItems: "center", paddingHorizontal: 9, paddingVertical: 5, borderRadius: 20, marginBottom: 13 },
  offerPillText: { color: brand.colors.navy, fontSize: 10, fontWeight: "800" },
  offerEyebrow: { color: "#76623B", fontSize: 11, fontWeight: "700", textAlign: "right" },
  offerTitle: { color: brand.colors.navy, fontSize: 22, fontWeight: "900", textAlign: "right", marginTop: 2 },
  offerDetail: { color: brand.colors.navy, fontSize: 18, fontWeight: "800", textAlign: "right", marginTop: 1 },
  offerNote: { color: "#685B42", fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 6, maxWidth: 260 },
  offerCta: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 12, paddingVertical: 8, paddingHorizontal: 11, backgroundColor: "#F8F2E4", borderRadius: 12 },
  offerCtaText: { color: brand.colors.navy, fontSize: 12, fontWeight: "800" },
  offerMedallion: { position: "absolute", left: 18, top: "28%", width: 78, height: 78, borderRadius: 39, backgroundColor: "#F8F2E4", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#D6C291" },
  offerBigMark: { color: brand.colors.gold, position: "absolute", right: 10, top: 5, fontSize: 13 },
  offerDots: { position: "absolute", bottom: 12, left: 22, flexDirection: "row", gap: 5 },
  offerDot: { width: 6, height: 6, borderRadius: 4, backgroundColor: "#C6B68F" },
  offerDotActive: { width: 17, backgroundColor: brand.colors.navy },
  stepsRow: { flexDirection: "row", gap: 9, flexWrap: "wrap" },
  stepCard: { flexGrow: 1, flexBasis: 118, backgroundColor: brand.colors.paper, borderRadius: 17, borderWidth: 1, borderColor: brand.colors.line, padding: 14, minHeight: 132 },
  stepTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  stepNumber: { fontSize: 12, fontWeight: "900", color: "#B9A77E" },
  stepTitle: { fontSize: 14, fontWeight: "900", color: brand.colors.navy, textAlign: "right", marginTop: 12 },
  stepDesc: { fontSize: 11, lineHeight: 17, color: brand.colors.muted, textAlign: "right", marginTop: 6 },
  reviewCard: { backgroundColor: brand.colors.paper, padding: 18, borderRadius: 19, borderWidth: 1, borderColor: brand.colors.line, alignItems: "flex-start" },
  reviewStars: { flexDirection: "row", gap: 2 },
  reviewPlaceholder: { color: brand.colors.ink, fontSize: 13, lineHeight: 22, textAlign: "right", marginTop: 12 },
  reviewFooter: { color: brand.colors.gold, fontSize: 11, fontWeight: "800", marginTop: 9, textAlign: "right" },
  footerLine: { marginTop: 18, textAlign: "center", fontSize: 12, color: brand.colors.muted, fontWeight: "700" },
});
