export type Audience = "طلاب" | "أساتذة" | "شركات";

export type Service = {
  id: string;
  name: string;
  detail: string;
  audience: Audience;
  icon: string;
};

export const audiences: { name: Audience; eyebrow: string; description: string; icon: string }[] = [
  { name: "طلاب", eyebrow: "جامعة • مدارس • طبي", description: "محتوى مرتب وواضح يساندك في المذاكرة والإنجاز.", icon: "school-outline" },
  { name: "أساتذة", eyebrow: "محاضرون وتعليم", description: "مواد تعليمية منظمة وجاهزة لتجربة شرح احترافية.", icon: "teach" },
  { name: "شركات", eyebrow: "مؤسسات وفرق", description: "مستندات وتقارير ومواد عمل تحافظ على وضوح رسالتكم.", icon: "office-building-outline" },
];

export const services: Service[] = [
  { id: "summaries", name: "ملخصات شاملة ومبسطة", detail: "تلخيص منظم يساعدك تراجع المهم خطوة بخطوة.", audience: "طلاب", icon: "book-open-page-variant-outline" },
  { id: "exams", name: "امتحانات تدريبية محلولة", detail: "نماذج تدريبية بإجابات مشروحة للمراجعة.", audience: "طلاب", icon: "clipboard-check-outline" },
  { id: "organizing", name: "ترتيب وتنظيم المواد", detail: "هيكلة واضحة لموادك وملفاتك الدراسية.", audience: "طلاب", icon: "folder-multiple-outline" },
  { id: "medical-terms", name: "مصطلحات طبية وإنجليزية", detail: "شرح مبسط للمفاهيم وMedical Terminology.", audience: "طلاب", icon: "stethoscope" },
  { id: "research", name: "واجبات وبحوث", detail: "مساعدة في التنظيم والتنسيق الأكاديمي.", audience: "طلاب", icon: "file-document-edit-outline" },
  { id: "presentations", name: "عروض PowerPoint", detail: "شرائح واضحة ومتوازنة بصرياً.", audience: "طلاب", icon: "presentation" },
  { id: "printing", name: "طباعة وتنسيق", detail: "تنسيق مرتب للمستندات والمواد الدراسية.", audience: "طلاب", icon: "printer-outline" },
  { id: "lectures", name: "تجهيز محاضرات", detail: "تنظيم المحتوى وتقديمه في تسلسل سهل للشرح.", audience: "أساتذة", icon: "school-outline" },
  { id: "question-banks", name: "بنوك أسئلة وامتحانات", detail: "إعداد وترتيب الأسئلة بما يناسب المادة.", audience: "أساتذة", icon: "clipboard-list-outline" },
  { id: "notes", name: "تنسيق مذكرات", detail: "مذكرات مرتبة تسهّل القراءة والمتابعة.", audience: "أساتذة", icon: "file-document-outline" },
  { id: "pro-presentations", name: "عروض تقديمية احترافية", detail: "عروض تعليمية واضحة ومهيأة للتقديم.", audience: "أساتذة", icon: "presentation-play" },
  { id: "reports", name: "تقارير وعروض احترافية", detail: "مخرجات مرتبة للعرض الداخلي أو الخارجي.", audience: "شركات", icon: "chart-box-outline" },
  { id: "company-profile", name: "بروفايل الشركة", detail: "تعريف مؤسسي يعرض نشاطكم بصورة منظمة.", audience: "شركات", icon: "domain" },
  { id: "archive", name: "تنظيم وأرشفة ملفات", detail: "هيكلة عملية تساعد الفريق في الوصول للمعلومة.", audience: "شركات", icon: "archive-outline" },
  { id: "training", name: "مواد تدريبية للموظفين", detail: "محتوى تدريبي واضح ومناسب لأهداف الفريق.", audience: "شركات", icon: "account-group-outline" },
  { id: "official-docs", name: "تنسيق مستندات رسمية", detail: "تنسيق رسمي متسق للوثائق المؤسسية.", audience: "شركات", icon: "file-certificate-outline" },
];

export const offerSlides = [
  {
    eyebrow: "عرض الطلاب",
    title: "ملخص + امتحان",
    detail: "وترتيب موادك مجاناً",
    note: "خطة أوضح للمراجعة، وخدمة التنظيم هدية مع الباقة.",
    icon: "gift-outline",
  },
  {
    eyebrow: "ميزة خاصة",
    title: "طلاب كلية النهضة",
    detail: "خصم خاص لكم",
    note: "راسلنا عبر واتساب واذكر كليتك للاستفادة من العرض.",
    icon: "star-four-points-outline",
  },
] as const;
