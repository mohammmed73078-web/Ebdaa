export const brand = {
  name: "مكتبة الإبداع الإلكترونية",
  manager: "د. محمد عماد الدين",
  colors: {
    navy: "#0A1F44",
    navySoft: "#17345E",
    gold: "#C9A86A",
    goldLight: "#E8D8B3",
    white: "#FFFFFF",
    beige: "#F7F3EA",
    paper: "#FFFDF9",
    ink: "#182438",
    muted: "#697386",
    line: "#E8E1D5",
    green: "#1E9B66",
    greenDark: "#167C52",
    rose: "#FFF0E9",
  },
} as const;

export type Country = "sudan" | "saudi";

export const contacts: Record<Country, { label: string; local: string; international: string; dialect: string }> = {
  sudan: { label: "السودان", local: "0124574325", international: "249124574325", dialect: "السودانية" },
  saudi: { label: "السعودية", local: "0539402773", international: "966539402773", dialect: "السعودية" },
};

export const openHoursNote = "تواصل معنا عبر واتساب، ونرد عليك في أقرب وقت متاح.";
