import { PropsWithChildren, useState } from "react";
import { Image, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { brand, contacts, Country } from "@/constants/brand";

export const imageLogoUri = "/manus-storage/async-images/IUwbogLfCsQvbsvVgLRwvD/image-1.webp";

export function openWhatsApp(country: Country = "sudan", message?: string) {
  const phone = contacts[country].international;
  const localizedMessage = message ?? (country === "sudan"
    ? "السلام عليكم، داير أستفسر عن خدمات مكتبة الإبداع الإلكترونية."
    : "السلام عليكم، أبغى أستفسر عن خدمات مكتبة الإبداع الإلكترونية.");
  const url = `https://wa.me/${phone}?text=${encodeURIComponent(localizedMessage)}`;
  void Linking.openURL(url).catch(() => undefined);
}

export function PageScreen({ children }: PropsWithChildren) {
  return (
    <SafeAreaView edges={["top"]} style={ui.safeArea}>
      <ScrollView contentContainerStyle={ui.pageScroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <View style={ui.pageContainer}>{children}</View>
      </ScrollView>
      <WhatsAppFab />
    </SafeAreaView>
  );
}

export function BrandHeader({ compact = false }: { compact?: boolean }) {
  return (
    <View style={ui.header}>
      <View style={ui.brandRow}>
        {Platform.OS === "web" ? (
          <Image source={{ uri: imageLogoUri }} style={ui.brandImage} resizeMode="cover" accessibilityLabel="شعار مكتبة الإبداع" />
        ) : (
          <View style={ui.brandMark}>
            <MaterialCommunityIcons name="book-open-page-variant" size={25} color={brand.colors.gold} />
            <View style={ui.miniCap}><MaterialCommunityIcons name="school" size={13} color={brand.colors.navy} /></View>
          </View>
        )}
        <View>
          <Text style={ui.brandName}>{compact ? "الإبداع" : "مكتبة الإبداع"}</Text>
          <Text style={ui.brandCaption}>الإلكترونية</Text>
        </View>
      </View>
      <View style={ui.headerBadge}><MaterialCommunityIcons name="star-four-points-outline" size={14} color={brand.colors.gold} /><Text style={ui.headerBadgeText}>معاك في مشوارك</Text></View>
    </View>
  );
}

export function SectionHeading({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return (
    <View style={ui.sectionHeading}>
      {eyebrow ? <Text style={ui.eyebrow}>{eyebrow}</Text> : null}
      <Text style={ui.sectionTitle}>{title}</Text>
      {subtitle ? <Text style={ui.sectionSubtitle}>{subtitle}</Text> : null}
    </View>
  );
}

export function SectionLabel({ children }: PropsWithChildren) {
  return <Text style={ui.sectionLabel}>{children}</Text>;
}

export function WhatsAppFab() {
  const [expanded, setExpanded] = useState(false);
  return (
    <View style={ui.fabWrap}>
      {expanded ? <View style={ui.fabChooser}>
        <Text style={ui.fabChooserTitle}>اختر رقم واتساب</Text>
        {(Object.keys(contacts) as Country[]).map((country) => <Pressable key={country} onPress={() => { setExpanded(false); openWhatsApp(country); }} style={({ pressed }) => [ui.fabCountry, pressed && { opacity: 0.7 }]}>
          <Text style={ui.fabCountryLabel}>{contacts[country].label}</Text><Text style={ui.fabCountryNumber}>{contacts[country].local}</Text>
        </Pressable>)}
      </View> : null}
      <Pressable onPress={() => setExpanded((value) => !value)} accessibilityRole="button" accessibilityLabel="اطلب الآن عبر واتساب؛ اختر السودان أو السعودية" style={({ pressed }) => [ui.fab, pressed && { opacity: 0.82, transform: [{ scale: 0.97 }] }]}>
        <MaterialCommunityIcons name={expanded ? "close" : "whatsapp"} size={21} color={brand.colors.white} />
        <Text style={ui.fabText}>{expanded ? "إغلاق" : "اطلب الآن"}</Text>
      </Pressable>
    </View>
  );
}

export function WhatsAppButton({ label = "راسلنا عبر واتساب", onPress, secondary = false }: { label?: string; onPress?: () => void; secondary?: boolean }) {
  return (
    <Pressable onPress={onPress ?? (() => openWhatsApp())} accessibilityRole="button" style={({ pressed }) => [ui.whatsAppButton, secondary && ui.whatsAppSecondary, pressed && { opacity: 0.84 }]}>
      <MaterialCommunityIcons name="whatsapp" size={20} color={secondary ? brand.colors.greenDark : brand.colors.white} />
      <Text style={[ui.whatsAppButtonText, secondary && ui.whatsAppSecondaryText]}>{label}</Text>
    </Pressable>
  );
}

export function IconTile({ icon, size = 22, tint = brand.colors.gold }: { icon: string; size?: number; tint?: string }) {
  return <View style={ui.iconTile}><MaterialCommunityIcons name={icon as never} size={size} color={tint} /></View>;
}

export function FooterContact() {
  return (
    <View style={ui.footerContact}>
      <Text style={ui.footerTitle}>نحن قريبين منك</Text>
      <View style={ui.contactRows}>
        {(Object.keys(contacts) as Country[]).map((key) => (
          <Pressable key={key} onPress={() => openWhatsApp(key)} style={({ pressed }) => [ui.contactPill, pressed && { opacity: 0.75 }]}>
            <MaterialCommunityIcons name="whatsapp" size={17} color={brand.colors.greenDark} />
            <Text style={ui.contactPillText}>{contacts[key].label} · {contacts[key].local}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

export function GoldRule() { return <View style={ui.goldRule} />; }

export function MiniFeature({ icon, title, detail }: { icon: string; title: string; detail: string }) {
  return (
    <View style={ui.miniFeature}>
      <IconTile icon={icon} size={20} />
      <View style={{ flex: 1 }}>
        <Text style={ui.miniFeatureTitle}>{title}</Text>
        <Text style={ui.miniFeatureDetail}>{detail}</Text>
      </View>
    </View>
  );
}

const ui = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: brand.colors.beige },
  pageScroll: { flexGrow: 1, paddingBottom: 112 },
  pageContainer: { width: "100%", maxWidth: 1120, alignSelf: "center", paddingHorizontal: 20, paddingTop: 10 },
  header: { minHeight: 60, flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 22 },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandImage: { width: 46, height: 46, borderRadius: 15, backgroundColor: brand.colors.navy },
  brandMark: { width: 46, height: 46, borderRadius: 15, backgroundColor: brand.colors.navy, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  miniCap: { position: "absolute", top: 3, right: 4, width: 18, height: 18, borderRadius: 9, backgroundColor: brand.colors.gold, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: brand.colors.navy },
  brandName: { fontSize: 15, fontWeight: "800", color: brand.colors.navy, textAlign: "right" },
  brandCaption: { fontSize: 11, color: brand.colors.muted, textAlign: "right", marginTop: 1 },
  headerBadge: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 30, backgroundColor: "#F1E7D4" },
  headerBadgeText: { fontSize: 11, color: brand.colors.navy, fontWeight: "700" },
  sectionHeading: { marginBottom: 16, alignItems: "flex-start" },
  eyebrow: { fontSize: 11, letterSpacing: 0.4, fontWeight: "800", color: brand.colors.gold, marginBottom: 6, textAlign: "right" },
  sectionTitle: { fontSize: 23, lineHeight: 32, fontWeight: "800", color: brand.colors.navy, textAlign: "right" },
  sectionSubtitle: { fontSize: 14, lineHeight: 23, color: brand.colors.muted, marginTop: 5, textAlign: "right" },
  sectionLabel: { fontSize: 14, fontWeight: "800", color: brand.colors.navy, textAlign: "right" },
  fabWrap: { position: "absolute", right: 18, bottom: Platform.OS === "web" ? 24 : 90, zIndex: 50, alignItems: "flex-end" },
  fab: { elevation: 8, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 17, height: 50, borderRadius: 28, backgroundColor: brand.colors.green, shadowColor: "#0B5237", shadowOpacity: 0.22, shadowRadius: 12, shadowOffset: { width: 0, height: 5 } },
  fabText: { color: brand.colors.white, fontSize: 13, fontWeight: "800" },
  fabChooser: { width: 190, backgroundColor: brand.colors.paper, padding: 12, borderRadius: 16, borderWidth: 1, borderColor: brand.colors.line, marginBottom: 9, shadowColor: brand.colors.navy, shadowOpacity: 0.12, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 5 },
  fabChooserTitle: { color: brand.colors.navy, fontSize: 12, fontWeight: "900", textAlign: "right", marginBottom: 6 },
  fabCountry: { minHeight: 40, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderTopWidth: 1, borderTopColor: brand.colors.line, paddingHorizontal: 2 },
  fabCountryLabel: { color: brand.colors.navy, fontSize: 12, fontWeight: "800" },
  fabCountryNumber: { color: brand.colors.muted, fontSize: 11 },
  whatsAppButton: { minHeight: 52, backgroundColor: brand.colors.green, borderRadius: 15, paddingHorizontal: 17, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9 },
  whatsAppButtonText: { fontSize: 14, fontWeight: "800", color: brand.colors.white },
  whatsAppSecondary: { backgroundColor: "#E9F5EE", borderWidth: 1, borderColor: "#C8E4D4" },
  whatsAppSecondaryText: { color: brand.colors.greenDark },
  iconTile: { width: 43, height: 43, borderRadius: 14, backgroundColor: "#F7F0E2", alignItems: "center", justifyContent: "center" },
  footerContact: { marginTop: 34, padding: 18, backgroundColor: brand.colors.paper, borderRadius: 20, borderWidth: 1, borderColor: brand.colors.line },
  footerTitle: { fontSize: 16, fontWeight: "800", color: brand.colors.navy, textAlign: "right", marginBottom: 12 },
  contactRows: { flexDirection: "row", flexWrap: "wrap", gap: 8, justifyContent: "flex-start" },
  contactPill: { minHeight: 42, flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#F4F7F4", paddingHorizontal: 12, borderRadius: 22 },
  contactPillText: { fontSize: 12, color: brand.colors.ink, fontWeight: "700" },
  goldRule: { width: 45, height: 3, borderRadius: 4, backgroundColor: brand.colors.gold, marginTop: 12, marginBottom: 16 },
  miniFeature: { flexDirection: "row", alignItems: "center", gap: 11, paddingVertical: 8 },
  miniFeatureTitle: { fontSize: 14, fontWeight: "800", color: brand.colors.navy, textAlign: "right" },
  miniFeatureDetail: { fontSize: 12, lineHeight: 19, color: brand.colors.muted, textAlign: "right", marginTop: 2 },
});
