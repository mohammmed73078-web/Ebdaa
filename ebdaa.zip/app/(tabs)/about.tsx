import { Pressable, StyleSheet, Text, View } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { brand, contacts, Country } from "@/constants/brand";
import { BrandHeader, FooterContact, IconTile, openWhatsApp, PageScreen, SectionHeading } from "@/components/brand-ui";

export default function AboutScreen() {
  return (
    <PageScreen>
      <BrandHeader compact />
      <SectionHeading eyebrow="عن المكتبة" title="مساحة تساعدك ترتّب طريقك" subtitle="خدمات أكاديمية ومهنية بجودة وتنظيم، وخطوات طلب بسيطة." />
      <View style={styles.aboutCard}>
        <View style={styles.profileIcon}><MaterialCommunityIcons name="stethoscope" size={30} color={brand.colors.gold} /><MaterialCommunityIcons name="book-open-page-variant" size={22} color="#F7F0E0" /></View>
        <Text style={styles.aboutEyebrow}>إدارة المكتبة</Text>
        <Text style={styles.name}>د. محمد عماد الدين</Text>
        <Text style={styles.role}>أخصائي تصوير طبي تشخيصي</Text>
        <View style={styles.goldLine} />
        <Text style={styles.bio}>بدأت الفكرة من إيماننا إن التنظيم والمساندة يصنعوا فرقاً في رحلة التعلّم والعمل. مكتبة الإبداع تجمع خدمات متنوعة للطلاب والأساتذة والشركات في مكان واحد.</Text>
        <View style={styles.achievement}><MaterialCommunityIcons name="trophy-outline" size={22} color={brand.colors.gold} /><View style={{ flex: 1 }}><Text style={styles.achievementTitle}>معدل كامل 4.0</Text><Text style={styles.achievementText}>وبقى بروف الدفعة بتوفيق الله.</Text></View></View>
      </View>

      <View style={styles.valuesBlock}>
        <SectionHeading eyebrow="أسلوبنا" title="واضح، منظم، وقريب منك" />
        <View style={styles.valueCard}><IconTile icon="check-decagram-outline" /><View style={{ flex: 1 }}><Text style={styles.valueTitle}>جودة وتنظيم</Text><Text style={styles.valueText}>نركز على وضوح المحتوى وترتيبه بما يناسب احتياجك.</Text></View></View>
        <View style={styles.valueCard}><IconTile icon="account-heart-outline" /><View style={{ flex: 1 }}><Text style={styles.valueTitle}>مساندة حقيقية</Text><Text style={styles.valueText}>نتابع معاك من اختيار الخدمة إلى استلام طلبك.</Text></View></View>
        <View style={styles.valueCard}><IconTile icon="clock-fast" /><View style={{ flex: 1 }}><Text style={styles.valueTitle}>خطوات بسيطة</Text><Text style={styles.valueText}>تواصل مباشر عبر واتساب من غير تعقيد.</Text></View></View>
      </View>

      <View style={styles.stepsCard}><Text style={styles.stepsTitle}>كيف تمشي الخطوة؟</Text>{[
        "اختار الخدمة المناسبة ليك.",
        "راسلنا بتفاصيلك والملف إن وجد.",
        "نوضح لك الخطوة التالية ووقت التسليم المتاح.",
      ].map((text, index) => <View key={text} style={styles.stepLine}><View style={styles.numberCircle}><Text style={styles.number}>{index + 1}</Text></View><Text style={styles.stepText}>{text}</Text></View>)}</View>

      <View style={styles.contactsCard}><Text style={styles.contactsTitle}>تواصل معنا من بلدك</Text><Text style={styles.contactsSub}>اختار الرقم المناسب، وابدأ محادثة واتساب مباشرة.</Text>{(Object.keys(contacts) as Country[]).map((key) => <Pressable key={key} onPress={() => openWhatsApp(key)} style={({ pressed }) => [styles.contactRow, pressed && { opacity: 0.82 }]}><View style={styles.contactIcon}><MaterialCommunityIcons name="whatsapp" size={20} color={brand.colors.greenDark} /></View><View style={{ flex: 1 }}><Text style={styles.country}>{contacts[key].label}</Text><Text style={styles.phoneNumber}>{contacts[key].local}</Text></View><MaterialCommunityIcons name="arrow-top-left" size={18} color={brand.colors.gold} /></Pressable>)}</View>
      <FooterContact />
    </PageScreen>
  );
}

const styles = StyleSheet.create({
  aboutCard: { backgroundColor: brand.colors.navy, borderRadius: 24, padding: 22, alignItems: "flex-start", overflow: "hidden" },
  profileIcon: { width: 68, height: 68, borderRadius: 22, backgroundColor: "#17355E", borderWidth: 1, borderColor: "#435777", alignItems: "center", justifyContent: "center", gap: 1, marginBottom: 15 },
  aboutEyebrow: { color: "#D6C493", fontSize: 11, fontWeight: "800", textAlign: "right" },
  name: { color: brand.colors.white, fontSize: 22, fontWeight: "900", textAlign: "right", marginTop: 4 },
  role: { color: "#D4DCEC", fontSize: 13, textAlign: "right", marginTop: 5 },
  goldLine: { height: 3, width: 44, backgroundColor: brand.colors.gold, borderRadius: 2, marginTop: 15, marginBottom: 13 },
  bio: { color: "#DDE5EF", fontSize: 13, textAlign: "right", lineHeight: 23 },
  achievement: { flexDirection: "row", alignItems: "center", gap: 11, marginTop: 19, backgroundColor: "#17355E", borderRadius: 14, padding: 12, width: "100%" },
  achievementTitle: { color: brand.colors.white, fontSize: 13, fontWeight: "900", textAlign: "right" },
  achievementText: { color: "#D5DDEC", fontSize: 11, marginTop: 3, textAlign: "right" },
  valuesBlock: { marginTop: 32 },
  valueCard: { flexDirection: "row", alignItems: "center", gap: 11, padding: 14, backgroundColor: brand.colors.paper, borderRadius: 16, borderWidth: 1, borderColor: brand.colors.line, marginBottom: 8 },
  valueTitle: { color: brand.colors.navy, fontSize: 13, fontWeight: "800", textAlign: "right" },
  valueText: { color: brand.colors.muted, fontSize: 11, lineHeight: 17, marginTop: 3, textAlign: "right" },
  stepsCard: { marginTop: 24, padding: 18, backgroundColor: "#EFE6D5", borderRadius: 19, borderWidth: 1, borderColor: "#E5D8C0" },
  stepsTitle: { fontSize: 15, fontWeight: "900", color: brand.colors.navy, textAlign: "right", marginBottom: 12 },
  stepLine: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 10 },
  numberCircle: { width: 26, height: 26, borderRadius: 13, backgroundColor: brand.colors.navy, alignItems: "center", justifyContent: "center" },
  number: { color: brand.colors.goldLight, fontSize: 11, fontWeight: "900" },
  stepText: { color: brand.colors.ink, fontSize: 12, flex: 1, textAlign: "right" },
  contactsCard: { marginTop: 27, padding: 18, backgroundColor: brand.colors.paper, borderRadius: 20, borderWidth: 1, borderColor: brand.colors.line },
  contactsTitle: { color: brand.colors.navy, fontSize: 16, fontWeight: "900", textAlign: "right" },
  contactsSub: { color: brand.colors.muted, fontSize: 11, textAlign: "right", marginTop: 5, marginBottom: 10 },
  contactRow: { minHeight: 63, flexDirection: "row", alignItems: "center", gap: 11, paddingHorizontal: 10, borderTopWidth: 1, borderTopColor: brand.colors.line },
  contactIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: "#E9F5EE", alignItems: "center", justifyContent: "center" },
  country: { color: brand.colors.navy, fontWeight: "800", fontSize: 12, textAlign: "right" },
  phoneNumber: { color: brand.colors.muted, fontSize: 12, marginTop: 3, textAlign: "right" },
});
