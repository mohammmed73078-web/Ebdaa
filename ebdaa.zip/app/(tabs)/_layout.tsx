import { Tabs } from "expo-router";
import { Platform, StyleSheet, View } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { brand } from "@/constants/brand";

const tabIcons: Record<string, string> = {
  index: "home-variant-outline",
  services: "book-open-page-variant-outline",
  request: "clipboard-text-outline",
  about: "information-outline",
};
const tabLabels: Record<string, string> = { index: "الرئيسية", services: "الخدمات", request: "اطلب", about: "عن المكتبة" };

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const paddingBottom = Platform.OS === "web" ? 8 : Math.max(insets.bottom, 8);
  return (
    <Tabs screenOptions={({ route }) => ({
      headerShown: false,
      tabBarButton: HapticTab,
      tabBarLabel: tabLabels[route.name] ?? "",
      tabBarIcon: ({ color, focused }) => <View style={[styles.iconWrap, focused && styles.iconWrapActive]}><MaterialCommunityIcons name={(tabIcons[route.name] ?? "circle-outline") as never} size={20} color={color} /></View>,
      tabBarActiveTintColor: brand.colors.navy,
      tabBarInactiveTintColor: "#8C929E",
      tabBarLabelStyle: { fontSize: 10, fontWeight: "700", marginBottom: 2 },
      tabBarStyle: { height: 58 + paddingBottom, paddingTop: 6, paddingBottom, backgroundColor: "#FFFDF9", borderTopColor: "#E8E1D5", borderTopWidth: StyleSheet.hairlineWidth, elevation: 10 },
    })}>
      <Tabs.Screen name="index" options={{ title: "الرئيسية" }} />
      <Tabs.Screen name="services" options={{ title: "الخدمات" }} />
      <Tabs.Screen name="request" options={{ title: "اطلب" }} />
      <Tabs.Screen name="about" options={{ title: "عن المكتبة" }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  iconWrap: { width: 34, height: 27, alignItems: "center", justifyContent: "center", borderRadius: 12 },
  iconWrapActive: { backgroundColor: "#EFE6D5" },
});
