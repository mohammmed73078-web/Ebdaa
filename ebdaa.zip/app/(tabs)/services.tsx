import { useMemo, useState } from "react";
import { useRouter } from "expo-router";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { audiences, services, Audience } from "@/constants/services";
import { brand } from "@/constants/brand";
import { BrandHeader, FooterContact, IconTile, PageScreen, SectionHeading } from "@/components/brand-ui";

export default function ServicesScreen() {
  const [active, setActive] = useState<Audience | "الكل">("الكل");
  const [search, setSearch] = useState("");
  const router = useRouter();
  const filtered = useMemo(() => services.filter((item) => (active === "الكل" || item.audience === active) && `${item.name} ${item.detail} ${item.audience}`.toLowerCase().includes(search.trim().toLowerCase())), [active, search]);

  return (
    <PageScreen>
      <BrandHeader compact />
      <SectionHeading eyebrow="خدماتنا" title="خدمة مرتبة.. لاحتياجك" subtitle="اختر الفئة المناسبة واكتشف التفاصيل، أو ابحث باسم الخدمة." />
      <View style={styles.searchBox}><MaterialCommunityIcons name="magnify" size={20} color={brand.colors.muted} /><TextInput value={search} onChangeText={setSearch} placeholder="ابحث عن خدمة أو مجال..." placeholderTextColor="#9097A4" textAlign="right" style={styles.searchInput} /></View>
      <View style={styles.filters}>{(["الكل", "طلاب", "أساتذة", "شركات"] as const).map((item) => <Pressable key={item} onPress={() => setActive(item)} style={[styles.filter, active === item && styles.filterActive]}><Text style={[styles.filterText, active === item && styles.filterTextActive]}>{item}</Text></Pressable>)}</View>
      {active === "الكل" && !search ? <View style={styles.audienceIntro}>{audiences.map((group) => <Pressable key={group.name} onPress={() => setActive(group.name)} style={styles.audienceChip}><MaterialCommunityIcons name={group.icon as never} size={18} color={brand.colors.gold} /><Text style={styles.audienceChipText}>{group.name}</Text><MaterialCommunityIcons name="chevron-left" size={16} color={brand.colors.muted} /></Pressable>)}</View> : null}
      <Text style={styles.resultsCount}>{filtered.length} خدمة متاحة</Text>
      <View style={styles.serviceGrid}>{filtered.map((item) => <Pressable key={item.id} onPress={() => router.push({ pathname: "/request", params: { service: item.name, audience: item.audience } })} style={({ pressed }) => [styles.serviceCard, pressed && { opacity: 0.84 }]}><View style={styles.serviceCardTop}><IconTile icon={item.icon} /><View style={styles.cardArrow}><MaterialCommunityIcons name="arrow-top-left" size={15} color={brand.colors.navy} /></View></View><Text style={styles.serviceName}>{item.name}</Text><Text style={styles.serviceDetail}>{item.detail}</Text><View style={styles.serviceFooter}><Text style={styles.audienceTag}>{item.audience}</Text><Text style={styles.orderText}>اطلب الخدمة</Text></View></Pressable>)}</View>
      {!filtered.length ? <View style={styles.empty}><MaterialCommunityIcons name="text-search" size={28} color={brand.colors.gold} /><Text style={styles.emptyTitle}>ما لقينا خدمة مطابقة</Text><Text style={styles.emptyText}>جرّب كلمة ثانية، أو راسلنا ونساعدك تختار.</Text></View> : null}
      <FooterContact />
    </PageScreen>
  );
}

const styles = StyleSheet.create({
  searchBox: { height: 50, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 13, backgroundColor: brand.colors.paper, borderRadius: 15, borderColor: brand.colors.line, borderWidth: 1, marginBottom: 13 },
  searchInput: { flex: 1, color: brand.colors.ink, fontSize: 14, minHeight: 46 },
  filters: { flexDirection: "row", gap: 8, marginBottom: 17, flexWrap: "wrap" },
  filter: { paddingHorizontal: 15, paddingVertical: 9, borderRadius: 22, backgroundColor: "#EFECE6", borderWidth: 1, borderColor: "#E5DED3" },
  filterActive: { backgroundColor: brand.colors.navy, borderColor: brand.colors.navy },
  filterText: { color: brand.colors.muted, fontSize: 12, fontWeight: "700" },
  filterTextActive: { color: brand.colors.white },
  audienceIntro: { gap: 8, marginBottom: 16 },
  audienceChip: { minHeight: 46, flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: brand.colors.paper, paddingHorizontal: 13, borderRadius: 13, borderWidth: 1, borderColor: brand.colors.line },
  audienceChipText: { color: brand.colors.navy, fontWeight: "800", fontSize: 13, flex: 1, textAlign: "right" },
  resultsCount: { color: brand.colors.muted, fontSize: 11, textAlign: "right", marginBottom: 9 },
  serviceGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  serviceCard: { flexGrow: 1, flexBasis: 150, maxWidth: 520, minHeight: 174, backgroundColor: brand.colors.paper, borderRadius: 18, padding: 14, borderWidth: 1, borderColor: brand.colors.line },
  serviceCardTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cardArrow: { width: 29, height: 29, borderRadius: 10, backgroundColor: "#F5F0E6", alignItems: "center", justifyContent: "center" },
  serviceName: { color: brand.colors.navy, fontWeight: "900", fontSize: 15, textAlign: "right", marginTop: 12 },
  serviceDetail: { color: brand.colors.muted, fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 5, flex: 1 },
  serviceFooter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 12 },
  audienceTag: { color: "#775C24", fontSize: 10, fontWeight: "800", backgroundColor: "#F2E8D5", paddingHorizontal: 8, paddingVertical: 5, borderRadius: 12 },
  orderText: { color: brand.colors.greenDark, fontSize: 11, fontWeight: "800" },
  empty: { marginTop: 25, padding: 24, alignItems: "center", borderRadius: 19, backgroundColor: brand.colors.paper, borderWidth: 1, borderColor: brand.colors.line },
  emptyTitle: { color: brand.colors.navy, fontWeight: "800", marginTop: 8 },
  emptyText: { color: brand.colors.muted, fontSize: 12, marginTop: 5, textAlign: "center" },
});
