import { useEffect, useMemo, useState } from "react";
import { useLocalSearchParams } from "expo-router";
import * as DocumentPicker from "expo-document-picker";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { audiences, services, Audience } from "@/constants/services";
import { brand, contacts, Country } from "@/constants/brand";
import { BrandHeader, FooterContact, openWhatsApp, PageScreen, SectionHeading, WhatsAppButton } from "@/components/brand-ui";

type SelectedFile = { name: string; size?: number | null; uri: string };

export default function RequestScreen() {
  const params = useLocalSearchParams<{ service?: string; audience?: string }>();
  const [name, setName] = useState("");
  const [audience, setAudience] = useState<Audience | "">("");
  const [service, setService] = useState("");
  const [subject, setSubject] = useState("");
  const [country, setCountry] = useState<Country>("sudan");
  const [file, setFile] = useState<SelectedFile | null>(null);
  const [error, setError] = useState("");
  const [serviceOpen, setServiceOpen] = useState(false);

  useEffect(() => {
    if (params.service) setService(params.service);
    if (params.audience && audiences.some((item) => item.name === params.audience)) setAudience(params.audience as Audience);
  }, [params.audience, params.service]);

  const availableServices = useMemo(() => audience ? services.filter((item) => item.audience === audience) : services, [audience]);
  async function chooseFile() {
    try {
      const result = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true, multiple: false, type: "*/*" });
      if (!result.canceled && result.assets[0]) setFile({ name: result.assets[0].name, size: result.assets[0].size, uri: result.assets[0].uri });
    } catch {
      setError("ما قدرنا نفتح الملفات. جرّب مرة ثانية.");
    }
  }
  function submit() {
    if (!name.trim() || !audience || !service) {
      setError("أكمل الاسم والفئة ونوع الخدمة عشان نجهز طلبك.");
      return;
    }
    setError("");
    const message = [
      country === "sudan"
        ? `السلام عليكم، أنا ${name.trim()} وداير أطلب الخدمة دي.`
        : `السلام عليكم، أنا ${name.trim()} وأبغى أطلب هذه الخدمة.`,
      `الفئة: ${audience}`,
      `الخدمة المطلوبة: ${service}`,
      subject.trim() ? `المادة / المجال: ${subject.trim()}` : null,
      file ? `الملف المرفق: ${file.name}` : null,
      file ? "سأرفق الملف من داخل محادثة واتساب." : null,
      `التواصل عبر رقم ${contacts[country].label}.`,
    ].filter(Boolean).join("\n");
    openWhatsApp(country, message);
  }

  return (
    <PageScreen>
      <BrandHeader compact />
      <SectionHeading eyebrow="ابدأ طلبك" title="خلّينا نرتبها معاك" subtitle="أرسل تفاصيل بسيطة، ونكمل معك على واتساب." />
      <View style={styles.formCard}>
        <Text style={styles.fieldLabel}>الاسم <Text style={styles.required}>*</Text></Text>
        <TextInput value={name} onChangeText={setName} placeholder="اكتب اسمك" placeholderTextColor="#9299A6" textAlign="right" style={styles.input} autoCapitalize="words" />

        <Text style={styles.fieldLabel}>الفئة <Text style={styles.required}>*</Text></Text>
        <View style={styles.choiceRow}>{audiences.map((item) => <Pressable key={item.name} onPress={() => { setAudience(item.name); setService(""); }} style={[styles.choice, audience === item.name && styles.choiceActive]}><Text style={[styles.choiceText, audience === item.name && styles.choiceTextActive]}>{item.name}</Text></Pressable>)}</View>

        <Text style={styles.fieldLabel}>نوع الخدمة <Text style={styles.required}>*</Text></Text>
        <Pressable onPress={() => setServiceOpen((prev) => !prev)} style={styles.selectButton}><Text style={[styles.selectText, !service && { color: "#9299A6" }]}>{service || "اختر الخدمة المناسبة"}</Text><MaterialCommunityIcons name={serviceOpen ? "chevron-up" : "chevron-down"} size={19} color={brand.colors.muted} /></Pressable>
        {serviceOpen ? <View style={styles.serviceOptions}>{availableServices.map((item) => <Pressable key={item.id} onPress={() => { setService(item.name); setServiceOpen(false); }} style={styles.serviceOption}><Text style={styles.serviceOptionText}>{item.name}</Text><MaterialCommunityIcons name="plus-circle-outline" size={17} color={brand.colors.gold} /></Pressable>)}</View> : null}

        <Text style={styles.fieldLabel}>المادة أو المجال <Text style={styles.optional}>(اختياري)</Text></Text>
        <TextInput value={subject} onChangeText={setSubject} placeholder="مثال: Anatomy، إدارة أعمال..." placeholderTextColor="#9299A6" textAlign="right" style={styles.input} />

        <Text style={styles.fieldLabel}>إرفاق ملف <Text style={styles.optional}>(اختياري)</Text></Text>
        <Pressable onPress={chooseFile} style={styles.filePicker}><View style={styles.uploadIcon}><MaterialCommunityIcons name="paperclip" size={20} color={brand.colors.gold} /></View><View style={{ flex: 1 }}><Text style={styles.filePickerTitle}>{file ? file.name : "اختار ملفاً من جهازك"}</Text><Text style={styles.filePickerHint}>{file ? "سيظهر اسم الملف في رسالة الطلب" : "PDF أو صورة أو مستند"}</Text></View><MaterialCommunityIcons name="upload-outline" size={19} color={brand.colors.navy} /></Pressable>
        {file ? <Pressable onPress={() => setFile(null)} style={styles.removeFile}><MaterialCommunityIcons name="close-circle-outline" size={15} color="#A4583F" /><Text style={styles.removeFileText}>إزالة الملف المختار</Text></Pressable> : null}
        <View style={styles.fileNotice}><MaterialCommunityIcons name="information-outline" size={17} color="#876B33" /><Text style={styles.fileNoticeText}>بعد فتح واتساب، أرفق الملف في المحادثة يدوياً. اختيار الملف هنا يضيف اسمه لرسالة الطلب فقط.</Text></View>

        <Text style={styles.fieldLabel}>رقم التواصل</Text>
        <View style={styles.countryRow}>{(Object.keys(contacts) as Country[]).map((key) => <Pressable key={key} onPress={() => setCountry(key)} style={[styles.countryChoice, country === key && styles.countryChoiceActive]}><Text style={[styles.countryName, country === key && styles.countryTextActive]}>{contacts[key].label}</Text><Text style={[styles.countryNumber, country === key && styles.countryTextActive]}>{contacts[key].local}</Text></Pressable>)}</View>
        {error ? <Text style={styles.error}>{error}</Text> : null}
        <View style={{ marginTop: 17 }}><WhatsAppButton label="أرسل الطلب عبر واتساب" onPress={submit} /></View>
        <Text style={styles.smallNote}>ما راح يتم إرسال طلبك إلا بعد ما تراجع الرسالة في واتساب وتضغط إرسال.</Text>
      </View>
      <FooterContact />
    </PageScreen>
  );
}

const styles = StyleSheet.create({
  formCard: { backgroundColor: brand.colors.paper, borderRadius: 22, padding: 18, borderWidth: 1, borderColor: brand.colors.line },
  fieldLabel: { fontSize: 13, fontWeight: "800", color: brand.colors.navy, textAlign: "right", marginBottom: 8, marginTop: 14 },
  required: { color: "#B35B3C" },
  optional: { color: brand.colors.muted, fontWeight: "500", fontSize: 11 },
  input: { minHeight: 49, borderRadius: 13, borderWidth: 1, borderColor: "#E5DFD5", backgroundColor: "#FDFBF7", paddingHorizontal: 13, color: brand.colors.ink, fontSize: 14 },
  choiceRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  choice: { minHeight: 42, flex: 1, minWidth: 80, alignItems: "center", justifyContent: "center", borderRadius: 13, borderWidth: 1, borderColor: brand.colors.line, backgroundColor: "#FBF9F5" },
  choiceActive: { backgroundColor: brand.colors.navy, borderColor: brand.colors.navy },
  choiceText: { color: brand.colors.muted, fontWeight: "700", fontSize: 13 },
  choiceTextActive: { color: brand.colors.white },
  selectButton: { minHeight: 49, borderRadius: 13, borderWidth: 1, borderColor: "#E5DFD5", backgroundColor: "#FDFBF7", paddingHorizontal: 13, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  selectText: { color: brand.colors.ink, fontSize: 13, flex: 1, textAlign: "right", marginRight: 10 },
  serviceOptions: { marginTop: 6, borderWidth: 1, borderColor: brand.colors.line, borderRadius: 14, backgroundColor: "#FFFEFC", overflow: "hidden" },
  serviceOption: { minHeight: 44, flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 13, borderBottomWidth: 1, borderBottomColor: "#F0EBE2" },
  serviceOptionText: { flex: 1, textAlign: "right", color: brand.colors.ink, fontSize: 12, fontWeight: "700", marginRight: 8 },
  filePicker: { minHeight: 70, borderRadius: 15, borderWidth: 1, borderStyle: "dashed", borderColor: "#CFC5B3", backgroundColor: "#FBF8F1", paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 10 },
  uploadIcon: { width: 39, height: 39, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "#F1E7D4" },
  filePickerTitle: { color: brand.colors.navy, fontWeight: "800", fontSize: 12, textAlign: "right" },
  filePickerHint: { color: brand.colors.muted, fontSize: 10, marginTop: 4, textAlign: "right" },
  removeFile: { flexDirection: "row", alignItems: "center", justifyContent: "flex-start", gap: 5, marginTop: 7 },
  removeFileText: { color: "#A4583F", fontSize: 11, fontWeight: "700" },
  fileNotice: { flexDirection: "row", alignItems: "flex-start", gap: 8, backgroundColor: "#F8F1E2", borderRadius: 12, padding: 11, marginTop: 9 },
  fileNoticeText: { color: "#6F5A33", fontSize: 10, lineHeight: 17, flex: 1, textAlign: "right" },
  countryRow: { flexDirection: "row", gap: 9 },
  countryChoice: { flex: 1, alignItems: "center", justifyContent: "center", minHeight: 61, borderRadius: 13, borderWidth: 1, borderColor: brand.colors.line, backgroundColor: "#FBF9F5" },
  countryChoiceActive: { backgroundColor: "#F0E7D7", borderColor: brand.colors.gold },
  countryName: { color: brand.colors.navy, fontSize: 12, fontWeight: "800" },
  countryNumber: { color: brand.colors.muted, fontSize: 11, marginTop: 3 },
  countryTextActive: { color: brand.colors.navy, fontWeight: "800" },
  error: { color: "#A74734", fontSize: 12, textAlign: "right", marginTop: 10, fontWeight: "700" },
  smallNote: { color: brand.colors.muted, fontSize: 10, textAlign: "center", lineHeight: 16, marginTop: 9 },
});
